package Domino;

public class Customer {
    int invoice;
    public Customer(int invoice) {
        this.invoice = invoice;
    }
}

