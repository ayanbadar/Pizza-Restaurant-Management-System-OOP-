package Domino;

public class DineIn extends Customer {

    public DineIn(int invoice) {
        super(invoice);

    }
}
